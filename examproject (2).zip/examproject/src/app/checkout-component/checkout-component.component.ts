import { Component } from '@angular/core';

@Component({
  selector: 'app-checkout-component',
  standalone: true,
  imports: [],
  templateUrl: './checkout-component.component.html',
  styleUrl: './checkout-component.component.css'
})
export class CheckoutComponentComponent {

}
