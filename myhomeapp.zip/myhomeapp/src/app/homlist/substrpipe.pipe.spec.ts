import { SubstrpipePipe } from './substrpipe.pipe';

describe('SubstrpipePipe', () => {
  it('create an instance', () => {
    const pipe = new SubstrpipePipe();
    expect(pipe).toBeTruthy();
  });
});
