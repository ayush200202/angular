import { Component, OnInit } from '@angular/core';
import { ReactiveFormsModule ,FormGroup, FormControl,Validators} from '@angular/forms';

@Component({
  selector: 'app-contactus',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './contactus.component.html',
  styleUrl: './contactus.component.css'
})
export class ContactusComponent implements OnInit {

  reactiveForm:FormGroup
  ngOnInit(): void {
    this.reactiveForm=new FormGroup({
      firstname:new FormControl("enter firstname",[Validators.required,Validators.pattern('[a-zA-Z]*')]),
      lastname:new FormControl(null,Validators.required),
      username:new FormControl(null),
      email:new FormControl("enter email")
    })
  }
  formDataSubmit() {
      console.log(this.reactiveForm)
    }
}
